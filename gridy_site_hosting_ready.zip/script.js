// Theme toggle and colorway accent handling
const toggle = document.querySelector('.theme-toggle');
toggle?.addEventListener('click', () => {
  toggle.classList.toggle('active');
  document.body.classList.toggle('light');
});

// Year
document.getElementById('y').textContent = new Date().getFullYear();

// Swatches -> body tint variable update
const map = {
  teal: '#0bb1a5',
  graphite: '#4b545a',
  aubergine: '#6b2c8f',
  rosegold: '#d6a191'
};
document.querySelectorAll('.swatch').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.swatch').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    const tint = map[btn.dataset.theme] || '#0bb1a5';
    document.documentElement.style.setProperty('--brand', tint);
    document.querySelector(':root').style.setProperty('--bg', '#0b1114');
    // Optional: pulse glow
    const glow = document.querySelector('.hero-art .glow');
    glow?.animate([{ opacity: .5 }, { opacity: 1 }], { duration: 600, fill: 'forwards' });
  });
});

// Fake submit for demo
document.querySelector('.signup')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const input = e.currentTarget.querySelector('input');
  if(!input.value) return;
  const prev = input.value;
  input.value = '';
  alert('Thanks! We will notify: ' + prev);
});